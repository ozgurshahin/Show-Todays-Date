document.addEventListener('DOMContentLoaded', function() {
    var currentDate = new Date();
    var dateString = currentDate.toDateString();
    document.getElementById('current-date').innerText = dateString;
});
